﻿using projetoweb2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace projetoweb2.Controllers
{
    public class IndicadorController : Controller
    {
        // GET: Indicador
        public ActionResult Index()
        {
            return View();
        }
    }
}